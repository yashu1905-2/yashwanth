# OCRmodelconversionGPUtoCPU
converting OCR MODEL 
